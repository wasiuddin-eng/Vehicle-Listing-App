<?php

require_once __DIR__ ."/VehicleBase.php";
require_once __DIR__ ."/VehicleActions.php";
require_once __DIR__ ."/FileHandler.php";

class VehicleManager extends VehicleBase implements VehicleActions{

use FileHandler;

 public function addVehicle($data){


    $vehicles = $this->readFile();

        $vehicles[] = $data;
        $this->writeFile($vehicles);


 }
    public function editVehicle($id,$data){



    }
    public function deleteVehicle($id){


    }
    public function getVehicle($id){


    }
   
   /* we  will  receive a error message if we do not use the function */
   
    public function getDetails(){




    }




}
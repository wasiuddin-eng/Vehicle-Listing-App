<?php

include("./header.php");
require_once("../../app/classes/VehicleManager.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $manager = new VehicleManager("","","","");
    $manager->addVehicle([
        'name'  => $_POST['name'],
        'type'  => $_POST['type'],
        'price' => $_POST['price'],
        'image' => $_POST['image']
    ]);

     header("Location: index.php");
    exit;

}
?>


<div class="container My-4"> 
<h2> Add  Vehicle </h2>
<form method="POST">
<div class="mb-3">
<label> Name</label>

<input type="text" name="type" class="from control required ">


 </div>

<div class="mb-3"> 
<label > Price </label>
<input type="text" name="price" class="from-control" required >
</div>

<div class="mb-3">
<label>Image URL</label>
<input type="text" name="image" class="form-control" required>
</div>

<button class="btn btn-success">Add</button>

</form>

</div>
</body>
</html>
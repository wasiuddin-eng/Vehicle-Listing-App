<?php
include './public/views/header.php';
?>

<div class="container my-4">
    <div class="Vehicle Container my-4">
        <a href="./public/views/add.php" class="btn btn-success mb-4">Add Vehicle</a>
        <div class="row">
            <!-- Loop Go here -->
            <div class="col-md-4">
                <div class="card" style="height: 200px; object-fit: cover;">
                    <img src="" class="card-img-top" style="height: 200px; object-fit: cover;">
                    <div class="card-body">
                        <h5 class="card-title">Title</h5>
                        <p class="card-text">Type: </p>
                        <p class="card-text">Price: $</p>
                        <a href="./views/edit.php?id=" class="btn btn-primary">Edit</a>
                        <a href="./views/delete.php?id=" class="btn btn-danger">Delete</a>
                    </div>
                </div>
            </div>
            <!-- Loop ends here -->
        </div>
    </div>
</div>

</body>
</html>